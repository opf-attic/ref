#!/bin/sh
python -u -m fido.run $*
