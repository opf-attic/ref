@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.nationalarchives.gov.uk/pronom/SignatureFile", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package uk.gov.nationalarchives.pronom;
